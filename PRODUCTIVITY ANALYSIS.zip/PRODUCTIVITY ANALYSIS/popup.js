function formatTime(ms) {
    const totalSec = Math.floor(ms / 1000);
    const min = Math.floor(totalSec / 60);
    const sec = totalSec % 60;
    return `${min}m ${sec}s`;
}

async function loadData() {
    const siteList = document.getElementById('siteList');
    siteList.innerHTML = '';
    const data = await chrome.storage.local.get(null);
    const sorted = Object.entries(data).sort((a, b) => b[1] - a[1]);

    for (const [site, time] of sorted) {
        const li = document.createElement('li');
        li.textContent = `${site}: ${formatTime(time)}`;
        siteList.appendChild(li);
    }
}

document.getElementById('clear').addEventListener('click', async () => {
    await chrome.storage.local.clear();
    loadData();
});

loadData();